import logging
from google.cloud import pubsub_v1
from concurrent.futures import TimeoutError


class PubSub:
    def __init__(self, project_id:str, topic_id:str) -> None:
        self.project_id = project_id
        self.topic_id = topic_id
        self.client = pubsub_v1.PublisherClient()


    def publisher(self, menssage:str):
        """
        Publishes a message to a specified Google Cloud Pub/Sub topic.

        Args:
            menssage (str): The message to be published to the topic.

        Raises:
            Exception: If publishing the message fails, the exception is logged and re-raised.
        """
        try:
            topic_path = self.client.topic_path(self.project_id, self.topic_id)
            self.client.publish(topic_path, menssage.encode("utf-8"))

        except Exception as e:
            logging.error(f"Failed to publish message: {str(e)}")
            raise


    def pull_messages(self, subscription_id:str, max_messages:int = 10, timeout:int = 10) -> list:
        """
        Pulls messages from a Google Cloud Pub/Sub subscription.

        Args:
            subscription_id (str): The ID of the subscription to pull messages from.
            max_messages (int): The maximum number of messages to pull.
            timeout (int): The timeout for pulling messages.

        Returns:
            list: A list of pulled messages.
        """
        subscription_path = self.client.subscription_path(self.project_id, subscription_id)
        response = self.client.pull(subscription_path, max_messages=max_messages, timeout=timeout)
        return response.received_messages



if __name__ == "__main__":
    # projects/default-project-mts/topics/tp-pj-streaming
    t = PubSub("default-project-mts", "tp-pj-streaming", "tp-pj-streaming-subs", 1)
    t.publisher('{"hello": "2131"}')